﻿
namespace SudokuWPF.Model.Enums
{
    public enum DifficultyLevels
    {
        ОченьЛегкий,
        Легкий,
        Средний,
        Сложный,
        Эксперт
    }
}
