﻿
namespace SudokuWPF.ViewModel.Enums
{
    public enum StartButtonStateEnum
    {
        Start,
        Pause,
        Resume,
        Disable
    }
}
